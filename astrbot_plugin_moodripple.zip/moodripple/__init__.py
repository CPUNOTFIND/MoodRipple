"""MoodRipple plugin services."""
